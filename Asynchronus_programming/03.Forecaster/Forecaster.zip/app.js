function attachEvents() {

    const inputLocation = document.getElementById('location');
    const getWeatherBtn = document.getElementById('submit');
    const forecast = document.querySelector('#forecast');
    const currentWeather = document.querySelector('#current');
    const upcomingWeather = document.querySelector('#upcoming');

    let conditionIcons = {
        'Sunny': '☀',
        'Partly sunny': '⛅',
        'Overcast': '☁',
        'Rain': '☂',
        'Degrees': '°',
    };

    let locationsUrl = 'http://localhost:3030/jsonstore/forecaster/locations';

    let oneDayForecatsUrl = 'http://localhost:3030/jsonstore/forecaster/today';

    let threeDayForecastUrl = 'http://localhost:3030/jsonstore/forecaster/upcoming';

    getWeatherBtn.addEventListener('click', getWeather);

    function getWeather() {

        fetch(locationsUrl)
            .then(res => res.json())
            .then(data => {
                currentWeather.textContent = '';
                const cityIndex = data.findIndex(el => el.name === inputLocation.value);
                forecast.style.display = 'block';

                if (cityIndex === -1) {
                    throw new Error('Error');
                };

                let cityCode = data[cityIndex].code;

                fetch(`${oneDayForecatsUrl}/${cityCode}`)
                    .then(res => res.json())
                    // .then(data => {
                    //     // Main div
                    //     const forecasts = document.createElement('div');
                    //     forecasts.classList.add('forecasts');

                    //     // Condition symbol span
                    //     const condSymbol = document.createElement('span');
                    //     condSymbol.className = 'condition-symbol';
                    //     condSymbol.innerHTML = conditions[data.forecast.condition];
                    //     forecast.appendChild(condSymbol)

                    //     // Condition info span
                    //     let condition = document.createElement('span');
                    //     condition.className = 'condition';

                    //     // Span 1
                    //     const span1 = document.createElement('span');
                    //     span1.className = 'forecast-data';
                    //     span1.textContent = data.name;
                    //     condition.appendChild(span1);

                    //     // Span 2
                    //     const span2 = document.createElement('span');
                    //     span1.className = 'forecast-data';
                    //     span1.textContent = `${data['low']}${symbols['Degrees']}/${data['high']}${symbols['Degrees']}`;
                    //     condition.appendChild(span2);

                    //     // Span 3
                    //     const span3 = document.createElement('span');
                    //     span1.className = 'forecast-data';
                    //     span1.textContent = data.forecast.condition;
                    //     condition.appendChild(span3);

                    //     forecasts.appendChild(condition);
                    //     currentWeather.appendChild(forecasts)


                    // })
                    .then(data => {

                        // console.log(data);
                        let currentForecastContainer = createElWithClassAndTextContent('div', 'forecasts', undefined);

                        let conditionIconSpanEl = createElWithClassAndTextContent('span', 'condition', `${conditionIcons[data.forecast['condition']]}`);
                        conditionIconSpanEl.classList.add('symbol');

                        let conditionsSpanEl = createElWithClassAndTextContent('span', 'condition', undefined)

                        let cityEl = createElWithClassAndTextContent('span', 'forecast-data', `${data.name}`);
                        let temperatureEl = createElWithClassAndTextContent('span', 'forecast-data', `${data.forecast['low']}${conditionIcons['Degrees']}/${data.forecast['high']}${conditionIcons['Degrees']}`);
                        let feelingEl = createElWithClassAndTextContent('span', 'forecast-data', data.condition);

                        conditionsSpanEl.appendChild(cityEl);
                        conditionsSpanEl.appendChild(temperatureEl);
                        conditionsSpanEl.appendChild(feelingEl);

                        currentForecastContainer.appendChild(conditionIconSpanEl);
                        currentForecastContainer.appendChild(conditionsSpanEl);

                        currentWeather.appendChild(currentForecastContainer)
                    })

                    fetch(`${threeDayForecastUrl}/${cityCode}`)
                    .then(res => res.json())
                    .then(data => {
                        upcomingWeather.textContent = '';
                        // console.log(data.forecast);
                        let upcomingForecastContainer = createElWithClassAndTextContent('div', 'forecast-info', undefined);
                        data.forecast.map(data => {
                            console.log(data);
                            
                            let upcomingSymbolEl = createElWithClassAndTextContent('span', 'symbol', undefined);
                                let upcomingConditionEl = createElWithClassAndTextContent('span', 'condition', undefined);
                                let upcomingTemperatureEl = createElWithClassAndTextContent('span', 'forecast-data', undefined);
                                let upcomingSpanEl = createElWithClassAndTextContent('span', 'upcoming', undefined);
            
                            upcomingSymbolEl.textContent = conditionIcons[data['condition']];
                            upcomingConditionEl.textContent = data.condition;
                            upcomingTemperatureEl.textContent = `${data['low']}${conditionIcons['Degrees']}/${data['high']}${conditionIcons['Degrees']}`;
        
                            upcomingForecastContainer.appendChild(upcomingSpanEl);
                            upcomingSpanEl.appendChild(upcomingSymbolEl);
                            upcomingSpanEl.appendChild(upcomingTemperatureEl);
                            upcomingSpanEl.appendChild(upcomingConditionEl);
                            
                            
                            
                            
                        })
                        
                        upcomingWeather.appendChild(upcomingForecastContainer);
                    })
                    .catch(err => upcomingWeather.style.display = 'none');
            })
            .catch(err => currentWeather.textContent = 'Error');


    }

    function createElWithClassAndTextContent(tagName, className, textContent) {
        const element = document.createElement(tagName);
        element.classList.add(className);
        element.textContent = textContent;
        return element;
    };


}

attachEvents();